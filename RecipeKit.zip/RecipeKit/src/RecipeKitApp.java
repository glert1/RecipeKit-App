public class RecipeKitApp {
    public static void main(String[] args) {
         sys system = new sys();
         system.welcome();

    }

}
