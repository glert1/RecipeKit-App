public enum Categories {
    CHICKEN_RECIPES, FISH_RECIPES, MEAT_RECIPES,SOUP_RECIPES, DESSERT_RECIPES;

    public String toString(){
        return name();
    }
}
